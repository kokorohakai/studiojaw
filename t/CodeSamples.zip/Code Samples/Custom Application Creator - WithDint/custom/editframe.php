<?
chdir("../");
require("../../home/header.php");
if ( $_GET['filename'] ) {
	$message = "<- click me when you are done, * = required.";
	$filedata = "";
	$header = '<?php require("../../home/header.php");?><body style="text-align:left;background:<?php echo $_SESSION["window-color"];?>">';
	$footer = '</body></html>';
	if ( count( $_FILES ) > 0 ){
		set_time_limit( 300 );
		if ( strlen( $_FILES["iconfile"]["name"] ) > 0 ) {
			$file = $_FILES["iconfile"]["name"];
			$file = str_replace("'","_",$file);
			$file = str_replace('"',"_",$file);
			$file = str_replace('/',"_",$file);
			$file = str_replace("\\","_",$file);			
			$file = str_replace(" ","_",$file);
			$fpath=$_SESSION['dint']."/custom/temp.png";
			move_uploaded_file( $_FILES["iconfile"]["tmp_name"], $fpath );
			$tpath=$_SESSION['dint']."/custom/".$_GET['filename'].".png";
			try {
					$image = new Imagick($fpath);
					$image->thumbnailImage(32,0);
					$image->writeImage($tpath);
			} catch ( Exception $e ){ }
			unlink($fpath);
			$message="saved!";
			?>
			<script languange="javascript" type="text/javascript">
				if ( confirm( "Click okay to refresh and apply, cancel to apply later." ) )
				{
					parent.parent.location=parent.parent.location;
				}
			</script>
			<?
		}
	}
	if ( isset ( $_POST['caption'] ) )
	{
		if ( strlen( $_POST['caption'] ) > 0  )
		{
			$file=$_SESSION['dint']."/custom/".$_GET['filename'].".ini";
			$fh = fopen( $file, "w" );
			fwrite($fh,"caption=".stripslashes($_POST['caption'])."\n");
			fwrite($fh,"name=".stripslashes($_POST['caption'])."\n");
			fwrite($fh,"windowcaption=".stripslashes($_POST['windowcaption'])."\n");
			fwrite($fh,"description=".stripslashes($_POST['windowcaption'])."\n");
			fwrite($fh,"security=".$_POST['security']."\n");
			fclose($fh);
			
			$file=$_SESSION['dint']."/custom/".$_GET['filename'].".php";
			$fh = fopen( $file, "w" );
			$filedata = stripslashes( $_POST['filedata'] );
			$filedata = str_replace("<?","",$filedata);
			$filedata = str_replace("<script","",$filedata);
			$filedata = str_replace("?>","",$filedata);
			$filedata = str_replace("<style","",$filedata);
			$filedata = $header.$filedata.$footer;
			fwrite($fh,$filedata);
			fclose($fh);
			logme( 'has updated the custom app "'.$_GET['filename'].'" to their dint!' );
			$message="saved app ".$_GET['filename'];
		}
	}

	$data = getinidata( $_SESSION['dint']."/custom/", $_GET['filename'] );
	$file=$_SESSION['dint']."/custom/".$_GET['filename'].".php";
	$fh = fopen( $file, "r" );
	@$filedata=fread( $fh, filesize($file) );
	@$filedata=str_replace($header,"",$filedata);
	@$filedata=str_replace($footer,"",$filedata);
	fclose($fh);
	?>
	<link rel="stylesheet" type="text/css" href="htmlarea/htmlarea.css">
	<script type="text/javascript" type="text/javascript">
		_editor_url = "htmlarea/";
	  _editor_lang = "en";
	</script>
	<script language="javascript" type="text/javascript" src="htmlarea/htmlarea.js"></script>
	<body style="background:white;">
		<form method="post" action="?filename=<?=$_GET['filename']?>" enctype="multipart/form-data" style="display:inline;">
			<table style="width:100%;height:100%;">
				<tr style="background:#DDD;">
					<td style="width:82px;text-align:right;">
						<input type="image" src="/home/images/save.png" alt="save">
					</td>
					<td style="color:red;text-align:left;">
						<?=$message?>
					</td>
				</tr>
				<tr>
					<td style="width:82px;text-align:right;">
						*Caption:
					</td>
					<td>
						<input type="text" style="width:100%;" name="caption" value="<?=$data['caption']?>">
					</td>
				</tr>
				<tr>
					<td style="width:82px;text-align:right;">
						Window:
					</td>
					<td>
						<input type="text" style="width:100%;" name="windowcaption" value="<?=$data['windowcaption']?>">
					</td>
				</tr>
				<tr>
					<td style="width:82px;text-align:right;">
						Security:
					</td>
					<td>
						<select name="security" style="width:100%;">
							<option value="public" <?=($data['security']=='public')?"selected":""?>>Public</option>
							<option value="friends" <?=($data['security']=='friends')?"selected":"";?>>Friends</option>
							<option value="private" <?=($data['security']=='private')?"selected":"";?>>Private</option>
						</select>
					</td>
				</tr>
				<tr>
					<td style="width:82px;text-align:right;">
						Icon:
					</td>
					<td>
						<input type="file" style="width:100%;" name="iconfile">
					</td>
				</tr>
				<tr>
					<td colspan=2 style="width:100%;height:100%;">
						<textarea name="filedata" id="filedata" class="filedata" style="width:100%;height:100%;margin:0px;border:0px;padding:0px;"><?=$filedata?></textarea>
					</td>
				</tr>
			</table>
			<script language="javascript" type="text/javascript">
			  //HTMLArea.loadPlugin("SpellChecker");//here as an example
		  	HTMLArea.onload = function() {
		  	  var editor = new HTMLArea("filedata");
			    //editor.registerPlugin(SpellChecker);
		      editor.generate();
		    };
		  	HTMLArea.init();
		  </script>
		</form>
<? 
} else {
?>
	<body style="background:white">
		Please select a file to edit.
<?
}
?>
</body></html>