<?
require("../../home/header.php");
?>
<body style="background:<?php echo $_SESSION['window-color'];?>">
	<table style="width:100%;height:100%;">
		<tr>
			<td style="background:gray;height:100%;width:150px;overflow:hidden;">
				<div style="height:100%;">
					<iframe src="custom/filelist.php" style="width:100%;height:100%;" id="filelist" name="filelist"></iframe>
				</div>
			</td>
			<td style="height:100%;">
				<iframe src="custom/editframe.php" style="width:100%;height:100%;" id="editframe" name="editframe"></iframe>
			</td>
		</tr>
	</table>
</body></html>