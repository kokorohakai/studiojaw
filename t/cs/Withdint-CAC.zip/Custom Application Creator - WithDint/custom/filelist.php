<?
chdir("../");
require("../../home/header.php");

if ( isdint() ) {
	if ( isset( $_POST['appname'] ) ) {
		$file=$_POST['appname'];
		$file=strtolower($file);
		$file=str_replace("/","",$file);
		$file=str_replace("\\","",$file);
		$file=str_replace("..","",$file);
		$file=str_replace(".","",$file);
		$file=str_replace(" ","",$file);
		$file=str_replace("?","",$file);
		$file=str_replace("*","",$file);
		$file=str_replace("#","",$file);
		$file=str_replace("$","",$file);
		if (strlen($file)>0) {
			exec( "touch ".$_SESSION['dint']."/custom/".$file.".php" );
			exec( "touch ".$_SESSION['dint']."/custom/".$file.".ini" );
			logme( 'has added a custom app "'.$file.'" to their dint!' );
			?>
			<!--<script languange="javascript" type="text/javascript">
				if ( confirm( "Click okay to refresh and apply, cancel to apply later." ) )
				{
					parent.parent.location=parent.parent.location;
				}
			</script>-->
		<?
		}
	}
	if ( isset( $_GET['delete'] ) ) {
		$file=$_GET['delete'];
		$file=strtolower($file);
		$file=str_replace("/","",$file);
		$file=str_replace("\\","",$file);
		$file=str_replace("..","",$file);
		$file=str_replace(".","",$file);
		$file=str_replace(" ","",$file);
		$file=str_replace("?","",$file);
		$file=str_replace("*","",$file);
		$file=str_replace("#","",$file);
		$file=str_replace("$","",$file);
		if (strlen($file)>0) {
			@unlink($_SESSION['dint']."/custom/".$file.".php");
			@unlink($_SESSION['dint']."/custom/".$file.".ini");
			@unlink($_SESSION['dint']."/custom/".$file.".png");
		}
		?>
		<!--<script languange="javascript" type="text/javascript">
			if ( confirm( "Click okay to refresh and apply, cancel to apply later." ) )
			{
				parent.parent.location=parent.parent.location;
			}
		</script>-->
		<?
	}	
	$customapps = scandir( $_SESSION['dint']."/custom/" );
	?>
	<body style="background:#EEE;text-align:left;">
		<form action="filelist.php" method="post">
			<input type="text" name="appname" style="width:100%;"><br>
			<input type="image" src="/home/images/create.png">
		</form>
		<?
		foreach ( $customapps as $app ) {
			if ( substr($app,-4,4) == ".php" ) {
				$app=substr($app,0,-4);
				?>
				<a href="?delete=<?=$app?>" onclick="return confirm('Click okay to delete <?=$app?>.')"><img src="/home/images/delete.jpg" style="vertical-align:middle;"></a><a href="editframe.php?filename=<?=$app?>" target="editframe"><?=$app?></a><br>
				<?
			}
		}
		?>
	</body></html>
<?
}
?>